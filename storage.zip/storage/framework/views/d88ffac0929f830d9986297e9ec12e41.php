<h3>Driver Behavior Report - <?php echo e($driver->names); ?></h3>
<p>Company: <?php echo e($company->name); ?></p>
<p>Date: <?php echo e(now()->format('d M Y')); ?></p>

<table width="100%" border="1" cellpadding="5" cellspacing="0">
    <thead>
        <tr>
            <th>#</th>
            <th>Behavior Category</th>
            <th>Behavior Type</th>
            <th>Description</th>
            <th>Reported By</th>
            <th>Date</th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $driver->behaviors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $behavior): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><?php echo e($index + 1); ?></td>
            <td><?php echo e($behavior->behaviorType->behaviorCategory->name ?? 'N/A'); ?></td>
            <td><?php echo e($behavior->behaviorType->name ?? 'N/A'); ?></td>
            <td><?php echo e($behavior->description ?? 'N/A'); ?></td>
            <td><?php echo e(optional($behavior->reporter)->name ?? 'System'); ?></td>
            <td><?php echo e($behavior->created_at?->format('d M Y - h:i A') ?? 'N/A'); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
            <td colspan="6" class="text-center">No behavior records found.</td>
        </tr>
        <?php endif; ?>
    </tbody>
</table>
<?php /**PATH D:\atpr rwanda\driver-cards-system\resources\views/company/drivers/behaviors_pdf.blade.php ENDPATH**/ ?>