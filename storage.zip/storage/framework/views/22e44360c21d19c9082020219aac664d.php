<div class="nk-footer">
  <div class="container-fluid">
    <div class="nk-footer-wrap">
      <div class="nk-footer-copyright"> &copy; <?php echo date("Y"); ?> <?php echo e(config('app.name')); ?>. Template by <a
          href="https://homiez.rw/" target="_blank">HOMIEZ</a>
      </div>
    </div>
  </div>
</div><?php /**PATH D:\atpr rwanda\driver-cards-system\resources\views/layouts/footer.blade.php ENDPATH**/ ?>