<?php $__env->startComponent('mail::message'); ?>
# Driver Behavior Report

Hello,

Please find attached the behavior report for driver: **<?php echo e($driver->names); ?>**.

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH D:\atpr rwanda\driver-cards-system\resources\views/emails/driver/behavior_report.blade.php ENDPATH**/ ?>