
<?php $__env->startSection('title', 'Driver Behavior History'); ?>
<?php $__env->startSection('content'); ?>

<div class="d-flex justify-content-between mb-3">
    <h5>
        Behavior History —
        <span class="fw-bold"><?php echo e($driver->names); ?></span>
    </h5>

    <a href="#" class="btn btn-secondary">
        ← Back to Drivers
    </a>

    <a href="<?php echo e(route('admin.driver.behaviors.download', $driver->id)); ?>" class="btn btn-primary">
        <em class="icon ni ni-download"></em> Download PDF
    </a>

    <button class="btn btn-success"
        data-bs-toggle="modal"
        data-bs-target="#sendBehaviorReportModal<?php echo e($driver->id); ?>">
        Send Report
    </button>

    <div class="modal fade"
        id="sendBehaviorReportModal<?php echo e($driver->id); ?>"
        tabindex="-1"
        aria-labelledby="sendBehaviorReportLabel<?php echo e($driver->id); ?>"
        aria-hidden="true">

        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">

                <form action="<?php echo e(route('admin.driver.behaviors.sendEmail', $driver->id)); ?>"
                    method="POST">
                    <?php echo csrf_field(); ?>

                    <div class="modal-header">
                        <h5 class="modal-title" id="sendBehaviorReportLabel<?php echo e($driver->id); ?>">
                            Send Behavior Report
                        </h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>

                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">Recipient Email</label>
                            <input type="email"
                                name="email"
                                class="form-control"
                                placeholder="Enter email address"
                                required>
                        </div>

                        <p class="text-muted small mb-0">
                            The behavior report for this driver will be generated and sent as a PDF.
                        </p>
                    </div>

                    <div class="modal-footer">
                        <button type="button"
                            class="btn btn-secondary"
                            data-bs-dismiss="modal">
                            Cancel
                        </button>

                        <button type="submit" class="btn btn-success">
                            Send Report
                        </button>
                    </div>

                </form>

            </div>
        </div>
    </div>


</div>

<div class="card p-4">
    <div class="card-title">
        Total Records: <?php echo e($driver->behaviors->count()); ?>

    </div>

    <table class="datatable-init nowrap nk-tb-list nk-tb-ulist">
        <thead>
            <tr class="nk-tb-item nk-tb-head">
                <th class="nk-tb-col">#</th>
                <th class="nk-tb-col">Behavior Type</th>
                <th class="nk-tb-col">Category</th>
                <th class="nk-tb-col">Description</th>
                <th class="nk-tb-col">Reported By</th>
                <th class="nk-tb-col">Date</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $driver->behaviors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $behavior): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr class="nk-tb-item">
                <td class="nk-tb-col"><?php echo e($index + 1); ?></td>
                <td class="nk-tb-col"><?php echo e($behavior->behaviorType->name ?? 'N/A'); ?></td>
                <td class="nk-tb-col"><?php echo e($behavior->behaviorType->behaviorCategory->name ?? 'N/A'); ?></td>
                <td class="nk-tb-col"><?php echo e($behavior->description ?? 'N/A'); ?></td>
                <td class="nk-tb-col"><?php echo e(optional($behavior->reporter)->name ?? 'System'); ?></td>
                <td class="nk-tb-col"><?php echo e($behavior->created_at?->format('d M Y - h:i A')); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="6" class="text-center">No behavior records found.</td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\atpr rwanda\driver-cards-system\resources\views/admin/drivers/behaviors.blade.php ENDPATH**/ ?>