<!DOCTYPE html>
<html lang="zxx" class="js">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />

<head>
  <meta charset="utf-8">
  <meta name="author" content="Softnio">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description"
    content="#">
  <link rel="shortcut icon" href="../../images/favicon.png">
  <title><?php echo $__env->yieldContent('title'); ?> | <?php echo e(config('app.name')); ?></title>
  <link rel="stylesheet" href="<?php echo e(asset('assets/css/dashlitee1e3.css?ver=3.2.4')); ?>">
  <link id="skin-default" rel="stylesheet" href="<?php echo e(asset('/assets/css/themee1e3.css?ver=3.2.4')); ?>">
  <script async src="https://www.googletagmanager.com/gtag/js?id=UA-91615293-4"></script>
  <script>
    window.dataLayer = window.dataLayer || [];

    function gtag() {
      dataLayer.push(arguments);
    }
    gtag('js', new Date());
    gtag('config', 'UA-91615293-4');
  </script>
</head>

<body class="nk-body bg-lighter npc-general has-sidebar ">
  <div class="nk-app-root">
    <div class="nk-main ">
      <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <div class="nk-wrap ">
        <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- End Header Top Area -->
        <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Main Menu area End-->
        <div class="nk-content ">
          <?php echo $__env->yieldContent('content'); ?>
        </div>
        <!-- Start Footer area-->

        <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- End Footer area-->
      </div>
    </div>
  </div>
  <script src="<?php echo e(asset('/assets/js/bundlee1e3.js?ver=3.2.4')); ?>"></script>
  <script src="<?php echo e(asset('/assets/js/scriptse1e3.js?ver=3.2.4')); ?>"></script>
  <script src="<?php echo e(asset('/assets/js/demo-settingse1e3.js?ver=3.2.4')); ?>"></script>
  <script src="<?php echo e(asset('/assets/js/libs/datatable-btnse1e3.js?ver=3.2.4')); ?>"></script>

</body>

</html><?php /**PATH D:\atpr rwanda\driver-cards-system\resources\views/layouts/app.blade.php ENDPATH**/ ?>