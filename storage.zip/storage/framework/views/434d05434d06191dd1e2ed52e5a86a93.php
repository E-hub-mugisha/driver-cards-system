

<?php $__env->startSection('title', 'Company Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="nk-content-inner">
        <div class="nk-content-body">

            
            <div class="nk-block-head nk-block-head-sm">
                <div class="nk-block-between">
                    <div class="nk-block-head-content">
                        <h3 class="nk-block-title page-title">
                            <?php echo e($company->name); ?> Overview
                        </h3>
                        <div class="nk-block-des text-soft">
                            <p>Welcome to your company dashboard.</p>
                        </div>
                    </div>

                    <div class="nk-block-head-content">
                        <a href="<?php echo e(route('company.reports.drivers')); ?>"
                           class="btn rounded-5"
                           style="background:#00ADEE; color:#fff">
                            <em class="icon ni ni-reports"></em>
                            <span>Reports</span>
                        </a>
                    </div>
                </div>
            </div>

            
            <div class="nk-block">
                <div class="row g-gs">

                    
                    <div class="col-md-6 col-lg-4">
                        <div class="card rounded-5 card-gradient"
                             style="background: linear-gradient(135deg, #00ADEE, #E3B228); color:#fff;">
                            <div class="card-inner">
                                <h6 class="title text-white">Drivers Overview</h6>
                                <p class="text-white mb-3">Your company driver statistics</p>

                                <div class="nk-sale-data-group g-4">
                                    <div class="nk-sale-data">
                                        <span class="amount">
                                            <?php echo e($DriversMonth); ?>

                                            <span class="change <?php echo e($MonthChange >= 0 ? 'up text-success' : 'down text-danger'); ?>">
                                                <em class="icon ni ni-arrow-long-<?php echo e($MonthChange >= 0 ? 'up' : 'down'); ?>"></em>
                                                <?php echo e(number_format($MonthChange, 2)); ?>%
                                            </span>
                                        </span>
                                        <span class="sub-title text-white">Last 30 Days</span>
                                    </div>

                                    <div class="nk-sale-data">
                                        <span class="amount">
                                            <?php echo e($DriversWeek); ?>

                                            <span class="change <?php echo e($WeekChange >= 0 ? 'up text-success' : 'down text-danger'); ?>">
                                                <em class="icon ni ni-arrow-long-<?php echo e($WeekChange >= 0 ? 'up' : 'down'); ?>"></em>
                                                <?php echo e(number_format($WeekChange, 2)); ?>%
                                            </span>
                                        </span>
                                        <span class="sub-title text-white">This Week</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    
                    <div class="col-md-6 col-lg-4">
                        <div class="card rounded-5">
                            <div class="card-inner">
                                <h6 class="title">Driver Status</h6>
                                <p class="mb-3">Current status distribution</p>

                                <div class="nk-sale-data-group g-4">
                                    <div class="nk-sale-data">
                                        <span class="amount text-success"><?php echo e($activeDrivers); ?></span>
                                        <span class="sub-title">Active</span>
                                    </div>

                                    <div class="nk-sale-data">
                                        <span class="amount text-warning"><?php echo e($pendingDrivers); ?></span>
                                        <span class="sub-title">Pending</span>
                                    </div>

                                    <div class="nk-sale-data">
                                        <span class="amount text-danger"><?php echo e($suspendedDrivers); ?></span>
                                        <span class="sub-title">Suspended</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

            
            <div class="nk-block">
                <div class="row g-gs">

                    <div class="col-lg-8">
                        <div class="card rounded-5 card-full">
                            <div class="card-inner border-bottom">
                                <div class="card-title-group">
                                    <h6 class="title">Recently Added Drivers</h6>
                                    <a href="<?php echo e(route('company.drivers.index')); ?>" class="link">
                                        View All
                                    </a>
                                </div>
                            </div>

                            <div class="card-inner p-0">
                                <div class="nk-tb-list nk-tb-orders">

                                    <div class="nk-tb-item nk-tb-head">
                                        <div class="nk-tb-col"><span>ID</span></div>
                                        <div class="nk-tb-col"><span>Name</span></div>
                                        <div class="nk-tb-col"><span>License</span></div>
                                        <div class="nk-tb-col"><span>Phone</span></div>
                                        <div class="nk-tb-col"><span>Status</span></div>
                                        <div class="nk-tb-col"></div>
                                    </div>

                                    <?php $__empty_1 = true; $__currentLoopData = $drivers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $driver): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <div class="nk-tb-item">
                                            <div class="nk-tb-col"><?php echo e($driver->ID_number); ?></div>
                                            <div class="nk-tb-col"><?php echo e($driver->names); ?></div>
                                            <div class="nk-tb-col text-primary"><?php echo e($driver->driver_license); ?></div>
                                            <div class="nk-tb-col"><?php echo e($driver->phone); ?></div>
                                            <div class="nk-tb-col">
                                                <span class="badge badge-dot bg-success">
                                                    <?php echo e(ucfirst($driver->status)); ?>

                                                </span>
                                            </div>
                                            <div class="nk-tb-col nk-tb-col-action">
                                                <a href="<?php echo e(route('company.drivers.show', $driver->id)); ?>"
                                                   class="btn btn-sm btn-outline-primary">
                                                    View
                                                </a>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <div class="nk-tb-item">
                                            <div class="nk-tb-col text-muted text-center">
                                                No drivers found.
                                            </div>
                                        </div>
                                    <?php endif; ?>

                                </div>
                            </div>
                        </div>
                    </div>

                    
                    <div class="col-lg-4">
                        <div class="card rounded-5 card-full">
                            <div class="card-inner border-bottom">
                                <h6 class="title">Recent Driver Reports</h6>
                            </div>

                            <ul class="nk-activity">
                                <?php $__empty_1 = true; $__currentLoopData = $reportedDrivers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <li class="nk-activity-item">
                                        <div class="nk-activity-media user-avatar bg-danger">
                                            <span><?php echo e(strtoupper(substr($report->driver->names ?? 'N', 0, 1))); ?></span>
                                        </div>
                                        <div class="nk-activity-data">
                                            <div class="label">
                                                <strong><?php echo e($report->driver->names ?? 'Unknown Driver'); ?></strong>
                                                reported for
                                                <span class="text-danger">
                                                    <?php echo e($report->behaviorType->behaviorCategory->name ?? 'Uncategorized'); ?>

                                                </span>
                                            </div>
                                            <span class="time">
                                                <?php echo e($report->behavior_date?->diffForHumans()); ?>

                                            </span>
                                        </div>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <li class="nk-activity-item">
                                        <div class="nk-activity-data text-muted">
                                            No recent reports
                                        </div>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </div>

                </div>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\atpr rwanda\driver-cards-system\resources\views/company/dashboard/index.blade.php ENDPATH**/ ?>