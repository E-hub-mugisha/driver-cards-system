<?php $__env->startSection('title', $driver->names . " - Details"); ?>
<?php $__env->startSection('content'); ?>
<div class="container">

    <a href="<?php echo e(url()->previous()); ?>" class="btn btn-secondary mb-3">Back</a>

    <div class="card shadow">
        <div class="card-body">
            <div class="d-flex justify-content-between align-items-start mb-2">

                <div>
                    <h4 class="mb-1">
                        <?php echo e($driver->names); ?>

                        <span class="badge 
                            <?php if($driver->performance_score >= 80): ?> bg-success
                            <?php elseif($driver->performance_score >= 60): ?> bg-primary
                            <?php elseif($driver->performance_score >= 40): ?> bg-warning
                            <?php else: ?> bg-danger <?php endif; ?>">
                            <?php echo e($driver->performance_rating); ?>

                        </span>
                    </h4>

                    <p class="text-muted mb-0">
                        Company: <strong><?php echo e($driver->company->name ?? 'Not Assigned'); ?></strong>
                    </p>
                </div>

                <div class="dropdown">
                    <button class="btn btn-secondary dropdown-toggle" type="button"
                        data-bs-toggle="dropdown">
                        Actions
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <?php if($driver->status != 'approved'): ?>
                        <li>
                            <button class="dropdown-item text-success"
                                data-bs-toggle="modal"
                                data-bs-target="#approveDriverModal">
                                Approve Driver
                            </button>
                        </li>
                        <?php endif; ?>
                        <li>
                            <?php if($driver->photo): ?>
                            <a class="dropdown-item"
                                href="<?php echo e(asset('storage/'.$driver->photo)); ?>" download>
                                Download Photo
                            </a>
                            <?php else: ?>
                            <span class="dropdown-item text-muted">No Photo</span>
                            <?php endif; ?>
                        </li>
                        <li>
                            <?php if($driver->contract): ?>
                            <a class="dropdown-item"
                                href="<?php echo e(asset('storage/'.$driver->contract)); ?>" download>
                                Download Contract
                            </a>
                            <?php else: ?>
                            <span class="dropdown-item text-muted">No Contract</span>
                            <?php endif; ?>
                        </li>
                        <li>
                            <hr class="dropdown-divider">
                        </li>
                        <li>
                            <a class="dropdown-item" data-bs-toggle="modal" data-bs-target="#editDriverModal<?php echo e($driver->id); ?>">
                                Edit Driver
                            </a>
                        </li>
                        <li>
                            <a class="dropdown-item text-danger" data-bs-toggle="modal" data-bs-target="#deleteDriverModal<?php echo e($driver->id); ?>">
                                Delete Driver
                            </a>
                        </li>
                    </ul>
                </div>
            </div>

            
            <ul class="nav nav-tabs" id="driverTabs" role="tablist">
                <li class="nav-item">
                    <a class="nav-link active" data-bs-toggle="tab" href="#profile">Profile</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" data-bs-toggle="tab" href="#documents">Documents</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" data-bs-toggle="tab" href="#behavior">Behavior History</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" data-bs-toggle="tab" href="#incidents">Incidents</a>
                </li>
            </ul>

            <div class="tab-content mt-3">

                
                <div class="tab-pane fade show active" id="profile">
                    <div class="row">
                        <div class="col-md-4">
                            <?php if($driver->photo): ?>
                            <img src="<?php echo e(asset('storage/'.$driver->photo)); ?>" class="img-fluid rounded shadow">
                            <?php else: ?>
                            <div class="alert alert-info">No Photo Uploaded</div>
                            <?php endif; ?>
                        </div>
                        <div class="col-md-8">
                            <table class="table table-bordered">
                                <tr>
                                    <th>Names</th>
                                    <td><?php echo e($driver->names); ?></td>
                                </tr>
                                <tr>
                                    <th>National ID</th>
                                    <td><?php echo e($driver->ID_number); ?></td>
                                </tr>
                                <tr>
                                    <th>Driver License</th>
                                    <td><?php echo e($driver->driver_license); ?></td>
                                </tr>
                                <tr>
                                    <th>Phone</th>
                                    <td><?php echo e($driver->phone); ?></td>
                                </tr>
                                <tr>
                                    <th>RSSB</th>
                                    <td><?php echo e($driver->rssb); ?></td>
                                </tr>
                                <tr>
                                    <th>Insurance</th>
                                    <td><?php echo e($driver->insurance); ?></td>
                                </tr>
                                <tr>
                                    <th>Contract Type</th>
                                    <td><?php echo e($driver->contract_type); ?></td>
                                </tr>
                                <tr>
                                    <th>Status</th>
                                    <td><?php echo e(ucfirst($driver->status)); ?></td>
                                </tr>
                                <tr>
                                    <th>Performance Score</th>
                                    <td><?php echo e($driver->performance_score); ?></td>
                                </tr>
                                <tr>
                                    <th>Performance Rating</th>
                                    <td><?php echo e($driver->performance_rating); ?></td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>

                
                <div class="tab-pane fade" id="documents">
                    <ul class="list-group">
                        <li class="list-group-item">
                            <strong>Photo:</strong>
                            <?php if($driver->photo): ?>
                            <a href="<?php echo e(asset('storage/'.$driver->photo)); ?>" target="_blank">View Photo</a>
                            <?php else: ?> <span class="text-danger">Not Uploaded</span> <?php endif; ?>
                        </li>
                        <li class="list-group-item">
                            <strong>Contract:</strong>
                            <?php if($driver->contract): ?>
                            <a href="<?php echo e(asset('storage/'.$driver->contract)); ?>" target="_blank">View Contract</a>
                            <?php else: ?> <span class="text-danger">Not Uploaded</span> <?php endif; ?>
                        </li>
                    </ul>
                </div>

                
                <div class="tab-pane fade" id="behavior">
                    <div class="d-flex justify-content-between">
                        <h5>Driver Behavior History</h5>
                        <button class="btn btn-sm btn-danger"
                            data-bs-toggle="modal"
                            data-bs-target="#addBehaviorModal-<?php echo e($driver->id); ?>">
                            Add Behavior
                        </button>
                    </div>

                    <table class="table table-bordered mt-3">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Category</th>
                                <th>Behavior</th>
                                <th>Severity</th>
                                <th>Score</th>
                                <th>Reported By</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $driver->behaviors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $behavior): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($behavior->behavior_date?->format('d M Y')); ?></td>
                                <td><?php echo e($behavior->behaviorType->behaviorCategory->name ?? 'N/A'); ?></td>
                                <td><?php echo e($behavior->behaviorType->name); ?></td>
                                <td>
                                    <span class="badge
                                        <?php if($behavior->severity === 'low'): ?> bg-info
                                        <?php elseif($behavior->severity === 'medium'): ?> bg-warning
                                        <?php else: ?> bg-danger <?php endif; ?>">
                                        <?php echo e(ucfirst($behavior->severity)); ?>

                                    </span>
                                </td>
                                <td><?php echo e($behavior->score); ?></td>
                                <td><?php echo e(optional($behavior->reporter)->name ?? 'System'); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="6" class="text-center text-muted">No behavior history found</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <div class="tab-pane fade" id="incidents">
                    <div class="d-flex justify-content-between">
                        <h5>Incident History</h5>

                        <button class="btn btn-sm btn-danger"
                            data-bs-toggle="modal"
                            data-bs-target="#addIncidentModal-<?php echo e($driver->id); ?>">
                            Record Incident
                        </button>
                    </div>

                    <table class="table table-bordered mt-3">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Type</th>
                                <th>Severity</th>
                                <th>Impact</th>
                                <th>Evidence</th>
                                <th>Reported By</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $driver->incidents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $incident): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($incident->incident_date); ?></td>
                                <td><?php echo e(ucfirst($incident->type)); ?></td>

                                <td>
                                    <span class="badge
<?php if($incident->severity=='low'): ?> bg-info
<?php elseif($incident->severity=='medium'): ?> bg-warning
<?php elseif($incident->severity=='high'): ?> bg-danger
<?php else: ?> bg-dark <?php endif; ?>">
                                        <?php echo e(ucfirst($incident->severity)); ?>

                                    </span>
                                </td>

                                <td><?php echo e($incident->impact_score); ?></td>

                                <td>
                                    <?php if($incident->evidence): ?>
                                    <a href="<?php echo e(asset('storage/'.$incident->evidence)); ?>" target="_blank">View</a>
                                    <?php else: ?>
                                    <span class="text-muted">No Evidence</span>
                                    <?php endif; ?>
                                </td>

                                <td><?php echo e($incident->reported_by); ?></td>

                                <td>
                                    <span class="badge
<?php if($incident->approval_status=='pending'): ?> bg-warning
<?php elseif($incident->approval_status=='approved'): ?> bg-success
<?php else: ?> bg-danger <?php endif; ?>">
                                        <?php echo e(ucfirst($incident->approval_status)); ?>

                                    </span>
                                </td>

                                <td>
                                    <?php if($incident->approval_status=='pending'): ?>
                                    <form method="POST"
                                        action="<?php echo e(route('admin.drivers.incidents.approve',$incident)); ?>"
                                        class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <button class="btn btn-sm btn-success">Approve</button>
                                    </form>

                                    <button class="btn btn-sm btn-danger"
                                        data-bs-toggle="modal"
                                        data-bs-target="#rejectIncident<?php echo e($incident->id); ?>">
                                        Reject
                                    </button>
                                    <?php endif; ?>
                                </td>
                            </tr>

                            
                            <div class="modal fade" id="rejectIncident<?php echo e($incident->id); ?>">
                                <div class="modal-dialog">
                                    <form class="modal-content"
                                        method="POST"
                                        action="<?php echo e(route('admin.drivers.incidents.reject',$incident)); ?>">
                                        <?php echo csrf_field(); ?>

                                        <div class="modal-header">
                                            <h5>Reject Incident</h5>
                                            <button class="btn-close" data-bs-dismiss="modal"></button>
                                        </div>

                                        <div class="modal-body">
                                            <textarea name="rejection_reason"
                                                class="form-control"
                                                placeholder="Reason for rejection"
                                                required></textarea>
                                        </div>

                                        <div class="modal-footer">
                                            <button class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                            <button class="btn btn-danger">Reject</button>
                                        </div>
                                    </form>
                                </div>
                            </div>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="8" class="text-center text-muted">
                                    No incidents recorded
                                </td>
                            </tr>
                            <?php endif; ?>
                        </tbody>

                    </table>
                </div>

            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="editDriverModal<?php echo e($driver->id); ?>">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form method="POST" action="<?php echo e(route('admin.drivers.update',$driver->id)); ?>" enctype="multipart/form-data"> <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?> <div class="modal-header">
                    <h5 class="modal-title">Edit Driver</h5> <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-md-6"> <label>Name</label> <input type="text" name="names" class="form-control" value="<?php echo e($driver->names); ?>" required> </div>
                        <div class="col-md-6"> <label>ID Number</label> <input type="text" name="ID_number" class="form-control" value="<?php echo e($driver->ID_number); ?>" required> </div>
                        <div class="col-md-6"> <label>Driver License</label> <input type="text" name="driver_license" class="form-control" value="<?php echo e($driver->driver_license); ?>" required> </div>
                        <div class="col-md-6"> <label>Phone</label> <input type="text" name="phone" class="form-control" value="<?php echo e($driver->phone); ?>" required> </div>
                        <div class="col-md-6"> <label>RSSB Number</label> <input type="text" name="rssb" class="form-control" value="<?php echo e($driver->rssb); ?>"> </div>
                        <div class="col-md-6"> <label>Insurance</label> <select name="insurance" class="form-select">
                                <option>YES</option>
                                <option>NO</option>
                            </select> </div>
                        <div class="col-md-6"> <label>Company</label> <select name="company_id" class="form-control">
                                <option value="">--Select Company--</option> <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($company->id); ?>" <?php echo e($driver->company_id==$company->id?'selected':''); ?>><?php echo e($company->name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select> </div>
                        <div class="col-md-6"> <label>Contract Type</label> <select name="contract_type" class="form-select">
                                <option value="3 month" <?php echo e($driver->contract_type=='3 month'?'selected':''); ?>>3 Month</option>
                                <option value="6 month" <?php echo e($driver->contract_type=='6 month'?'selected':''); ?>>6 Month</option>
                                <option value="12 month" <?php echo e($driver->contract_type=='12 month'?'selected':''); ?>>12 Month</option>
                                <option value="open ended" <?php echo e($driver->contract_type=='open ended'?'selected':''); ?>>Open Ended</option>
                            </select> </div>
                        <div class="col-md-6"> <label>Status</label> <select name="status" class="form-control">
                                <option value="active" <?php echo e($driver->status=='active'?'selected':''); ?>>Active</option>
                                <option value="inactive" <?php echo e($driver->status=='inactive'?'selected':''); ?>>Inactive</option>
                                <option value="suspended" <?php echo e($driver->status=='suspended'?'selected':''); ?>>Suspended</option>
                            </select> </div>
                        <div class="col-md-6"> <label>Photo</label> <input type="file" name="photo" class="form-control"> <?php if($driver->photo): ?> <small>Current: <a href="<?php echo e(asset('storage/'.$driver->photo)); ?>" target="_blank">View</a></small> <?php endif; ?> </div>
                        <div class="col-md-6"> <label>Contract</label> <input type="file" name="contract" class="form-control"> <?php if($driver->contract): ?> <small>Current: <a href="<?php echo e(asset('storage/'.$driver->contract)); ?>" target="_blank">View</a></small> <?php endif; ?> </div>
                    </div>
                </div>
                <div class="modal-footer"> <button class="btn btn-secondary" data-bs-dismiss="modal">Close</button> <button class="btn btn-success">Update</button> </div>
            </form>
        </div>
    </div>
</div> <!-- Delete Driver Modal -->
<div class="modal fade" id="deleteDriverModal<?php echo e($driver->id); ?>">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST" action="<?php echo e(route('admin.drivers.destroy',$driver->id)); ?>"> <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?> <div class="modal-header">
                    <h5 class="modal-title text-danger">Confirm Remove</h5> <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body"> Are you sure you want to remove <b><?php echo e($driver->names); ?></b>? </div>
                <div class="modal-footer"> <button class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button> <button class="btn btn-danger">Remove</button> </div>
            </form>
        </div>
    </div>
</div> <?php if($driver->status != 'approved'): ?> <div class="modal fade" id="approveDriverModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form action="<?php echo e(route('admin.drivers.approve', $driver->id)); ?>" method="POST"> <?php echo csrf_field(); ?> <div class="modal-header">
                    <h5 class="modal-title">Confirm Approval</h5> <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <p> Are you sure you want to <strong>approve</strong> this driver? </p>
                    <div class="alert alert-info"> ✔ Driver will become approved<br> ✔ Status will update immediately </div>
                </div>
                <div class="modal-footer"> <button class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button> <button class="btn btn-success">Yes, Approve</button> </div>
            </form>
        </div>
    </div>
</div> <?php endif; ?>
<!-- REPORT BEHAVIOR MODAL -->
<div class="modal fade" id="addBehaviorModal-<?php echo e($driver->id); ?>">
    <div class="modal-dialog">
        <form method="POST" action="<?php echo e(route('admin.drivers.behaviors.store', $driver)); ?>" class="modal-content"> <?php echo csrf_field(); ?> <input type="hidden" name="driver_id" value="<?php echo e($driver->id); ?>">
            <div class="modal-header">
                <h5>Report Behavior – <?php echo e($driver->names); ?></h5> <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body"> <!-- Behavior Category --> <select class="form-control mb-2" id="categorySelect-<?php echo e($driver->id); ?>" required>
                    <option value="">Select Category</option> <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select> <!-- Behavior --> <select name="behavior_type_id" class="form-control mb-2" id="behaviorSelect-<?php echo e($driver->id); ?>" required>
                    <option value="">Select Behavior</option> <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php $__currentLoopData = $cat->behaviorTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($b->id); ?>" data-cat="<?php echo e($cat->id); ?>" data-category="<?php echo e($b->category); ?>" data-score="<?php echo e($b->default_score); ?>" style="display:none;"> <?php echo e($b->name); ?> </option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select> <!-- Severity --> <select name="severity" class="form-control mb-2" id="severitySelect-<?php echo e($driver->id); ?>" required>
                    <option value="low">Low</option>
                    <option value="medium">Medium</option>
                    <option value="high">High</option>
                </select> <!-- Behavior Date --> <input type="date" name="behavior_date" class="form-control mb-2" value="<?php echo e(date('Y-m-d')); ?>" required> <!-- Final Score (auto-filled) --> <input type="number" name="score" class="form-control mb-2" placeholder="Final Score (auto-calculated)" readonly> <!-- Description --> <textarea name="description" class="form-control" placeholder="Description (optional)"></textarea> </div>
            <div class="modal-footer"> <button type="submit" class="btn btn-primary">Submit</button> <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button> </div>
        </form>
    </div>
</div>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const categorySelect = document.getElementById('categorySelect-<?php echo e($driver->id); ?>');
        const behaviorSelect = document.getElementById('behaviorSelect-<?php echo e($driver->id); ?>');
        const severitySelect = document.getElementById('severitySelect-<?php echo e($driver->id); ?>');
        const scoreInput = behaviorSelect.form.score;
        const weights = {
            'low': 5,
            'medium': 10,
            'high': 20
        };

        function updateScore() {
            const defaultScore = parseFloat(behaviorSelect.selectedOptions[0]?.dataset.score || 0);
            const severityScore = weights[severitySelect.value] || 0;
            let finalScore = defaultScore + severityScore;
            const category = behaviorSelect.selectedOptions[0]?.dataset.category || 'positive';
            if (category === 'negative') {
                finalScore = -Math.abs(finalScore);
            }
            scoreInput.value = finalScore;
        }
        categorySelect.addEventListener('change', function() {
            const selectedCat = this.value;
            behaviorSelect.value = '';
            scoreInput.value = '';
            behaviorSelect.querySelectorAll('option').forEach(opt => {
                if (!opt.value) return;
                opt.style.display = (opt.dataset.cat === selectedCat) ? 'block' : 'none';
            });
        });
        behaviorSelect.addEventListener('change', updateScore);
        severitySelect.addEventListener('change', updateScore);
    });
</script>


<div class="modal fade" id="addIncidentModal-<?php echo e($driver->id); ?>">
    <div class="modal-dialog">
        <form method="POST" enctype="multipart/form-data"
            action="<?php echo e(route('admin.drivers.incidents.store',$driver)); ?>"
            class="modal-content">
            <?php echo csrf_field(); ?>

            <div class="modal-header">
                <h5>Record Incident – <?php echo e($driver->names); ?></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            <div class="modal-body">

                <select name="type" class="form-control mb-2" required>
                    <option value="">Select Incident Type</option>
                    <option value="accident">Accident</option>
                    <option value="traffic_violation">Traffic Violation</option>
                    <option value="vehicle_damage">Vehicle Damage</option>
                    <option value="complaint">Complaint</option>
                    <option value="other">Other</option>
                </select>

                <select name="severity" class="form-control mb-2">
                    <option value="low">Low</option>
                    <option value="medium">Medium</option>
                    <option value="high">High</option>
                    <option value="critical">Critical</option>
                </select>

                <input type="date" name="incident_date"
                    value="<?php echo e(date('Y-m-d')); ?>"
                    class="form-control mb-2" required>

                <input type="text" name="location"
                    class="form-control mb-2"
                    placeholder="Location (optional)">
                <hr>
                <h6>Root Cause & Responsibility</h6>

                <select name="root_cause_category" class="form-control mb-2">
                    <option value="">Select Root Cause</option>
                    <option value="human_error">Human Error</option>
                    <option value="mechanical_failure">Mechanical Failure</option>
                    <option value="environment">Environment</option>
                    <option value="policy_violation">Policy Violation</option>
                    <option value="training_gap">Training Gap</option>
                    <option value="fatigue">Fatigue</option>
                    <option value="other">Other</option>
                </select>

                <textarea name="root_cause_details"
                    class="form-control mb-2"
                    placeholder="Explain what caused this incident..."></textarea>

                <select name="responsibility" class="form-control mb-2">
                    <option value="driver">Driver</option>
                    <option value="company">Company</option>
                    <option value="third_party">Third Party</option>
                    <option value="shared">Shared</option>
                    <option value="unknown">Unknown</option>
                </select>

                <textarea name="description"
                    class="form-control mb-2"
                    placeholder="Incident details..."></textarea>

                <input type="file" name="evidence" class="form-control">
            </div>

            <div class="modal-footer">
                <button class="btn btn-primary">Save</button>
                <button class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
            </div>

        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\atpr rwanda\driver-cards-system\resources\views/admin/drivers/show.blade.php ENDPATH**/ ?>