
<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    <div class="nk-content-inner">
        <div class="nk-content-body">
            <div class="nk-block-head nk-block-head-sm">
                <div class="nk-block-between">
                    <div class="nk-block-head-content">
                        <h3 class="nk-block-title page-title"><?php echo e(config('app.name')); ?> Overview</h3>
                        <div class="nk-block-des text-soft">
                            <p>Welcome to <?php echo e(config('app.name')); ?> Dashboard.</p>
                        </div>
                    </div>
                    <div class="nk-block-head-content">
                        <div class="toggle-wrap nk-block-tools-toggle"><a href="#"
                                class="btn btn-icon btn-trigger toggle-expand me-n1"
                                data-target="pageMenu"><em class="icon ni ni-more-v"></em></a>
                            <div class="toggle-expand-content" data-content="pageMenu">
                                <ul class="nk-block-tools g-3">
                                    <li>
                                        <div class="dropdown"><a href="#"
                                                class="dropdown-toggle btn btn-white btn-dim btn-outline-light"
                                                data-bs-toggle="dropdown"><em
                                                    class="d-none d-sm-inline icon ni ni-calender-date"></em><span><span
                                                        class="d-none d-md-inline">Last</span> 30
                                                    Days</span><em
                                                    class="dd-indc icon ni ni-chevron-right"></em></a>
                                            <div class="dropdown-menu dropdown-menu-end">
                                                <ul class="link-list-opt no-bdr">
                                                    <li><a href="#"><span>Last 30 Days</span></a>
                                                    </li>
                                                    <li><a href="#"><span>Last 6 Months</span></a>
                                                    </li>
                                                    <li><a href="#"><span>Last 1 Years</span></a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </li>
                                    <li class="nk-block-tools-opt"><a href="#"
                                            class="btn rounded-5" style="background:#00ADEE; color:#fff"><em
                                                class="icon ni ni-reports"></em><span>Reports</span></a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="nk-block">
                <div class="row g-gs">
                    <div class="col-xxl-12">
                        <div class="row g-gs">
                            <div class="col-md-4">
                                <div class="card rounded-5 card-gradient" style="background: linear-gradient(135deg, #00ADEE, #E3B228); color: #fff;">
                                    <div class="card-inner">
                                        <div class="card-title-group align-start mb-2">
                                            <div class="card-title">
                                                <h6 class="title text-white">Total Drivers</h6>
                                                <p class="mb-0 text-white">Driver statistics overview</p>
                                            </div>

                                            <div class="card-tools">
                                                <em class="card-hint icon ni ni-help-fill"
                                                    data-bs-toggle="tooltip"
                                                    data-bs-placement="left"
                                                    title="Drivers registered in the system"></em>
                                            </div>
                                        </div>

                                        <div class="align-end gy-3 gx-5 flex-wrap flex-md-nowrap flex-lg-wrap flex-xxl-nowrap">

                                            
                                            <div class="nk-sale-data-group flex-md-nowrap g-4">

                                                <div class="nk-sale-data">
                                                    <span class="amount">
                                                        <?php echo e($DriversMonth); ?>

                                                        <span class="change <?php echo e($MonthChange >= 0 ? 'up text-success' : 'down text-danger'); ?>">
                                                            <em class="icon ni ni-arrow-long-<?php echo e($MonthChange >= 0 ? 'up' : 'down'); ?>"></em>
                                                            <?php echo e(number_format($MonthChange,2)); ?>%
                                                        </span>
                                                    </span>
                                                    <span class="sub-title text-white">Last 30 Days</span>
                                                </div>

                                                <div class="nk-sale-data">
                                                    <span class="amount">
                                                        <?php echo e($DriversWeek); ?>

                                                        <span class="change <?php echo e($WeekChange >= 0 ? 'up text-success' : 'down text-danger'); ?>">
                                                            <em class="icon ni ni-arrow-long-<?php echo e($WeekChange >= 0 ? 'up' : 'down'); ?>"></em>
                                                            <?php echo e(number_format($WeekChange,2)); ?>%
                                                        </span>
                                                    </span>
                                                    <span class="sub-title text-white">This Week</span>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>

                            </div>
                            <div class="col-md-4">
                                <div class="card rounded-5" style="background: linear-gradient(135deg, #ffffffff, #E3B228);">
                                    <div class="card-inner">
                                        <div class="card-title-group align-start mb-2">
                                            <div class="card-title">
                                                <h6 class="title">Drivers Status Overview</h6>
                                                <p>Active, Suspended and Pending Drivers</p>
                                            </div>

                                            <div class="card-tools">
                                                <em class="card-hint icon ni ni-help-fill"
                                                    data-bs-toggle="tooltip"
                                                    data-bs-placement="left"
                                                    title="Current driver status distribution"></em>
                                            </div>
                                        </div>

                                        <div class="align-end flex-sm-wrap g-4 flex-md-nowrap">

                                            <div class="nk-sale-data">
                                                <span class="amount text-success"><?php echo e($activeDrivers); ?></span>
                                                <span class="sub-title">Active Drivers</span>
                                            </div>

                                            <div class="nk-sale-data">
                                                <span class="amount text-warning"><?php echo e($pendingDrivers); ?></span>
                                                <span class="sub-title">Pending Approval</span>
                                            </div>

                                            <div class="nk-sale-data">
                                                <span class="amount text-danger"><?php echo e($suspendedDrivers); ?></span>
                                                <span class="sub-title">Suspended Drivers</span>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="card rounded-5" style="background: linear-gradient(135deg, #00ADEE, #ffffffff);">
                                    <div class="card-inner">
                                        <div class="card-title-group align-start mb-2">
                                            <div class="card-title">
                                                <h6 class="text-white">Avg Registered Companies</h6>
                                                <p class="text-white">Companies registration overview</p>
                                            </div>

                                            <div class="card-tools">
                                                <em class="card-hint icon ni ni-help-fill"
                                                    data-bs-toggle="tooltip"
                                                    data-bs-placement="left"
                                                    title="Daily average number of companies registered"></em>
                                            </div>
                                        </div>

                                        <div class="align-end flex-sm-wrap g-4 flex-md-nowrap">
                                            <div class="nk-sale-data">
                                                <span class="amount">
                                                    <?php echo e(number_format($avgCompaniesPerDay, 1)); ?>

                                                </span>

                                                <span class="sub-title">
                                                    <span class="change <?php echo e($companyChange >= 0 ? 'up text-success' : 'down text-danger'); ?>">
                                                        <em class="icon ni ni-arrow-long-<?php echo e($companyChange >= 0 ? 'up' : 'down'); ?>"></em>
                                                        <?php echo e(number_format($companyChange,2)); ?>%
                                                    </span>
                                                    since last week
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xxl-8">
                        <div class="card rounded-5 card-full">
                            <div class="card-inner">
                                <div class="card-title-group">
                                    <div class="card-title">
                                        <h6 class="title"><span class="me-2">Recent Drivers added</span> <a
                                                href="<?php echo e(route('admin.drivers.index')); ?>" class="link d-none d-sm-inline">See
                                                All</a></h6>
                                    </div>
                                    <div class="card-tools">
                                        <ul class="card-tools-nav">
                                            <li><a href="#"><span>Paid</span></a></li>
                                            <li><a href="#"><span>Pending</span></a></li>
                                            <li class="active"><a href="<?php echo e(route('admin.drivers.index')); ?>"><span>All</span></a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="card-inner p-0 border-top">
                                <div class="nk-tb-list nk-tb-orders">
                                    <div class="nk-tb-item nk-tb-head">
                                        <div class="nk-tb-col"><span>Driver No.</span></div>
                                        <div class="nk-tb-col tb-col-sm"><span>Names</span></div>
                                        <div class="nk-tb-col tb-col-md"><span>Company</span></div>
                                        <div class="nk-tb-col tb-col-lg"><span>License</span></div>
                                        <div class="nk-tb-col"><span>Phone</span></div>
                                        <div class="nk-tb-col"><span
                                                class="d-none d-sm-inline">Status</span></div>
                                        <div class="nk-tb-col"><span>&nbsp;</span></div>
                                    </div>
                                    <?php $__currentLoopData = $drivers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $driver): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="nk-tb-item">
                                        <div class="nk-tb-col"><span class="tb-lead"><a
                                                    href="#"><?php echo e($driver->ID_number); ?></a></span></div>
                                        <div class="nk-tb-col tb-col-sm">
                                            <div class="user-card">
                                                <div class="user-avatar user-avatar-sm bg-purple">
                                                    <span>AB</span>
                                                </div>
                                                <div class="user-name"><span class="tb-lead"><?php echo e($driver->names); ?></span></div>
                                            </div>
                                        </div>
                                        <div class="nk-tb-col tb-col-md"><span
                                                class="tb-sub"><?php echo e($driver->company?->name ?? '-'); ?></span></div>
                                        <div class="nk-tb-col tb-col-lg"><span
                                                class="tb-sub text-primary"><?php echo e($driver->driver_license); ?></span></div>
                                        <div class="nk-tb-col"><span
                                                class="tb-sub tb-amount"><?php echo e($driver->phone); ?>

                                            </span></div>
                                        <div class="nk-tb-col"><span
                                                class="badge badge-dot badge-dot-xs bg-success"><?php echo e(ucfirst($driver->status)); ?></span>
                                        </div>
                                        <div class="nk-tb-col nk-tb-col-action">
                                            <div class="dropdown"><a
                                                    class="text-soft dropdown-toggle btn btn-icon btn-trigger"
                                                    data-bs-toggle="dropdown"><em
                                                        class="icon ni ni-more-h"></em></a>
                                                <div
                                                    class="dropdown-menu dropdown-menu-end dropdown-menu-xs">
                                                    <ul class="link-list-plain">
                                                        <li><a href="<?php echo e(route('admin.drivers.show', $driver->id )); ?>">View</a></li>
                                                        <!-- <li><a href="#">Invoice</a></li>
                                                        <li><a href="#">Print</a></li> -->
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                            <div class="card-inner-sm border-top text-center d-sm-none"><a href="#"
                                    class="btn btn-link btn-block">See History</a></div>
                        </div>
                    </div>
                    <div class="col-md-6 col-xxl-4">
                        <div class="card rounded-5 card-full">
                            <div class="card-inner border-bottom">
                                <div class="card-title-group">
                                    <div class="card-title">
                                        <h6 class="title">Recent Reported Drivers</h6>
                                    </div>
                                    <div class="card-tools">
                                        <ul class="card-tools-nav">
                                            <li class="active"><a href="#"><span>All</span></a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <ul class="nk-activity">
                                <?php $__empty_1 = true; $__currentLoopData = $reportedDrivers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <li class="nk-activity-item">
                                    <div class="nk-activity-media user-avatar bg-danger">
                                        <span>
                                            <?php echo e(strtoupper(substr($report->driver->names ?? 'N', 0, 1))); ?>

                                        </span>
                                    </div>

                                    <div class="nk-activity-data">
                                        <div class="label">
                                            <strong><?php echo e($report->driver->names ?? 'Unknown Driver'); ?></strong>
                                            was reported for
                                            <span class="text-danger">
                                                <?php echo e($report->behaviorType->behaviorCategory->name 
                        ?? 'Uncategorized Behavior'); ?>

                                            </span>
                                        </div>

                                        <span class="time">
                                            <?php echo e($report->behavior_date?->diffForHumans() ?? $report->created_at->diffForHumans()); ?>

                                        </span>
                                    </div>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <li class="nk-activity-item">
                                    <div class="nk-activity-data">
                                        <div class="label text-muted">No recent behavior reports</div>
                                    </div>
                                </li>
                                <?php endif; ?>
                            </ul>

                        </div>
                    </div>
                    <div class="col-md-6 col-xxl-4">
                        <div class="card rounded-5 card-full">
                            <div class="card-inner-group">
                                <div class="card-inner">
                                    <div class="card-title-group">
                                        <div class="card-title">
                                            <h6 class="title">New Users</h6>
                                        </div>

                                        <div class="card-tools">
                                            <a href="<?php echo e(route('admin.users.index')); ?>" class="link">
                                                View All
                                            </a>
                                        </div>
                                    </div>
                                </div>

                                <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="card-inner card-inner-md">
                                    <div class="user-card">

                                        <!-- Avatar -->
                                        <div class="user-avatar bg-primary-dim">
                                            <span>
                                                <?php echo e(strtoupper(substr($user->name,0,1))); ?>

                                                <?php echo e(strtoupper(substr(last(explode(' ', $user->name)),0,1))); ?>

                                            </span>
                                        </div>

                                        <!-- User Info -->
                                        <div class="user-info">
                                            <span class="lead-text"><?php echo e($user->name); ?></span>
                                            <span class="sub-text"><?php echo e($user->email); ?></span>
                                        </div>

                                        <!-- Actions -->
                                        <div class="user-action">
                                            <div class="dropdown">
                                                <a href="#" class="dropdown-toggle btn btn-icon btn-trigger me-n1"
                                                    data-bs-toggle="dropdown">
                                                    <em class="icon ni ni-more-h"></em>
                                                </a>

                                                <div class="dropdown-menu dropdown-menu-end">
                                                    <ul class="link-list-opt no-bdr">
                                                        <li>
                                                            <a href="#">
                                                                <em class="icon ni ni-user-list"></em>
                                                                <span>View Profile</span>
                                                            </a>
                                                        </li>

                                                        <li>
                                                            <a href="#">
                                                                <em class="icon ni ni-notify"></em>
                                                                <span>Send Notification</span>
                                                            </a>
                                                        </li>

                                                    </ul>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <div class="card-inner">
                                    <p class="text-center text-muted">No new users found.</p>
                                </div>
                                <?php endif; ?>

                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-xxl-4">
                        <div class="card rounded-5 h-100">
                            <div class="card-inner border-bottom">
                                <div class="card-title-group">
                                    <div class="card-title">
                                        <h6 class="title">Recent Companies</h6>
                                    </div>
                                    <div class="card-tools"><a href="<?php echo e(route('admin.companies.index')); ?>" class="link">All Companies</a>
                                    </div>
                                </div>
                            </div>
                            <ul class="nk-support">
                                <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="nk-support-item">
                                    <div class="user-avatar">
                                        <span>
                                            <?php echo e(strtoupper(substr($company->name,0,1))); ?>

                                            <?php echo e(strtoupper(substr(last(explode(' ', $company->name)),0,1))); ?>

                                        </span>
                                    </div>
                                    <div class="nk-support-content">
                                        <div class="title"><span><?php echo e($company->name); ?></span><span
                                                class="badge badge-dot badge-dot-xs ms-1 <?php if($company->status=='active'): ?> bg-success
                        <?php elseif($company->status=='suspended'): ?> bg-danger
                        <?php else: ?> bg-secondary <?php endif; ?>"><?php echo e(ucfirst($company->status)); ?></span>
                                        </div>
                                        <p><?php echo e($company->email); ?></p><span
                                            class="time"><?php echo e($company->address); ?></span>
                                    </div>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-6 col-xxl-4">
                        <div class="card rounded-5 h-100">
                            <div class="card-inner border-bottom">
                                <div class="card-title-group">
                                    <div class="card-title">
                                        <h6 class="title">Notifications</h6>
                                    </div>
                                    <div class="card-tools"><a href="#" class="link">View All</a>
                                    </div>
                                </div>
                            </div>
                            <div class="card-inner">
                                <div class="timeline">
                                    <h6 class="timeline-head">November, 2019</h6>
                                    <ul class="timeline-list">
                                        <li class="timeline-item">
                                            <div class="timeline-status bg-primary is-outline">
                                            </div>
                                            <div class="timeline-date">13 Nov <em
                                                    class="icon ni ni-alarm-alt"></em></div>
                                            <div class="timeline-data">
                                                <h6 class="timeline-title">Submited KYC Application
                                                </h6>
                                                <div class="timeline-des">
                                                    <p>Re-submitted KYC Application form.</p><span
                                                        class="time">09:30am</span>
                                                </div>
                                            </div>
                                        </li>
                                        <li class="timeline-item">
                                            <div class="timeline-status bg-primary"></div>
                                            <div class="timeline-date">13 Nov <em
                                                    class="icon ni ni-alarm-alt"></em></div>
                                            <div class="timeline-data">
                                                <h6 class="timeline-title">Submited KYC Application
                                                </h6>
                                                <div class="timeline-des">
                                                    <p>Re-submitted KYC Application form.</p><span
                                                        class="time">09:30am</span>
                                                </div>
                                            </div>
                                        </li>
                                        <li class="timeline-item">
                                            <div class="timeline-status bg-pink"></div>
                                            <div class="timeline-date">13 Nov <em
                                                    class="icon ni ni-alarm-alt"></em></div>
                                            <div class="timeline-data">
                                                <h6 class="timeline-title">Submited KYC Application
                                                </h6>
                                                <div class="timeline-des">
                                                    <p>Re-submitted KYC Application form.</p><span
                                                        class="time">09:30am</span>
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\atpr rwanda\driver-cards-system\resources\views/admin/dashboard/index.blade.php ENDPATH**/ ?>