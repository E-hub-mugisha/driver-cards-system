<?php echo e($slot); ?>

<?php /**PATH D:\atpr rwanda\driver-cards-system\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>