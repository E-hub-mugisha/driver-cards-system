<?php $__env->startSection('title', 'Companies'); ?>
<?php $__env->startSection('content'); ?>

<!-- Breadcomb area Start-->
<div class="container-fluid">
    <div class="nk-content-inner">
        <div class="nk-content-body">
            <div class="nk-block-head nk-block-head-sm">
                <div class="nk-block-between mb-3">
                    <div class="nk-block-head-content">
                        <h3 class="nk-block-title page-title">Company Management</h3>
                    </div>
                    <div class="nk-block-head-content">
                        <div class="toggle-wrap nk-block-tools-toggle">
                            <a href="#"
                                class="btn btn-icon btn-trigger toggle-expand me-n1"
                                data-target="pageMenu">
                                <em class="icon ni ni-more-v"></em>
                            </a>

                            <div class="toggle-expand-content" data-content="pageMenu">
                                <ul class="nk-block-tools g-3">
                                    <li class="nk-block-tools-opt">

                                        <!-- Mobile -->
                                        <a href="#"
                                            data-bs-toggle="modal"
                                            data-bs-target="#createCompanyModal"
                                            class="btn btn-icon rounded-5 d-md-none"
                                            style="background-color:#00ADEE;color:#fff">
                                            <em class="icon ni ni-plus"></em>
                                        </a>

                                        <!-- Desktop -->
                                        <a href="#"
                                            data-bs-toggle="modal"
                                            data-bs-target="#createCompanyModal"
                                            class="btn rounded-5 d-none d-md-inline-flex"
                                            style="background-color:#00ADEE;color:#fff">
                                            <em class="icon ni ni-plus"></em>
                                            <span>Add Company</span>
                                        </a>

                                    </li>
                                </ul>
                            </div>
                        </div>

                    </div>
                </div>

                <?php if(session('success')): ?>
                <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                <?php endif; ?>

                <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <li><?php echo e($e); ?></li> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php endif; ?>

                <div class="nk-block nk-block-lg bg-white rounded-5 shadow-sm p-4">
                    <div class="nk-block-head">
                        <div class="nk-block-head-content">
                            <div class="nk-block-des">
                                <p>Below is the list of all companies registered in the system.</p>
                            </div>
                        </div>
                    </div>
                    <table class="datatable-init nowrap nk-tb-list nk-tb-ulist" data-auto-responsive="false">
                        <thead>
                            <tr class="nk-tb-item nk-tb-head">
                                <th class="nk-tb-col">#</th>
                                <th class="nk-tb-col">Name</th>
                                <th class="nk-tb-col">Email</th>
                                <th class="nk-tb-col tb-col-lg">Address </th>
                                <th class="nk-tb-col tb-col-lg">Phone </th>
                                <th class="nk-tb-col">Status</th>
                                <th class="nk-tb-col">Drivers</th>
                                <th class="nk-tb-col">Staff</th>
                                <th class="nk-tb-col nk-tb-col-tools text-end">Action</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="nk-tb-item">
                                <td class="nk-tb-col"><?php echo e($companies->firstItem() + $key); ?></td>
                                <td class="nk-tb-col">
                                    <div class="user-card">
                                        <div class="user-avatar bg-dim-primary d-none d-sm-flex">
                                            <span><?php echo e(substr($company->name, 0, 2)); ?></span>
                                        </div>
                                        <div class="user-info">
                                            <span class="tb-lead"><?php echo e($company->name); ?>

                                            </span>
                                        </div>
                                    </div>
                                </td>
                                <td class="nk-tb-col tb-col-lg"><?php echo e($company->email); ?></td>
                                <td class="nk-tb-col tb-col-lg"><?php echo e($company->address); ?></td>
                                <td class="nk-tb-col tb-col-lg"><?php echo e($company->phone); ?></td>
                                <td class="nk-tb-col tb-col-lg">
                                    <span class=" 
                        <?php if($company->status=='active'): ?> text-success
                        <?php elseif($company->status=='suspended'): ?> text-danger
                        <?php else: ?> text-secondary <?php endif; ?>">
                                        <?php echo e(ucfirst($company->status)); ?>

                                    </span>
                                </td>

                                <td class="nk-tb-col tb-col-lg"><?php echo e($company->drivers()->count() ?? 0); ?></td>
                                <td class="nk-tb-col tb-col-lg"><?php echo e($company->staff()->count() ?? 0); ?></td>

                                <td class="nk-tb-col nk-tb-col-tools">
                                    <ul class="nk-tb-actions gx-1">
                                        <li>
                                            <div class="drodown">
                                                <a href="#"
                                                    class="dropdown-toggle btn btn-icon btn-trigger"
                                                    data-bs-toggle="dropdown"><em
                                                        class="icon ni ni-more-h"></em></a>
                                                <div
                                                    class="dropdown-menu dropdown-menu-end">
                                                    <ul class="link-list-opt no-bdr">
                                                        <li>
                                                            <a href="<?php echo e(route('admin.company.staff.index',$company->id)); ?>">
                                                                <em class="icon ni ni-users"></em><span>View Staff</span>
                                                            </a>
                                                        </li>
                                                        <li>
                                                            <a href="<?php echo e(route('admin.company.drivers.index',$company->id)); ?>">
                                                                <em class="icon ni ni-users"></em><span>View Drivers</span>
                                                            </a>
                                                        </li>
                                                        <li>
                                                            <a href="#"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#payrollSettingsModal<?php echo e($company->id); ?>">
                                                                <em class="icon ni ni-coins"></em><span>Payroll Settings</span>
                                                            </a>
                                                        </li>
                                                        <li>
                                                            <a href="#"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#editCompanyModal<?php echo e($company->id); ?>">
                                                                <em class="icon ni ni-edit"></em><span>Edit Company</span>
                                                            </a>
                                                        </li>
                                                        <li>
                                                            <a href="#"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#deleteCompanyModal<?php echo e($company->id); ?>">
                                                                <em class="icon ni ni-trash"></em><span>Delete Company</span>
                                                            </a>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </li>
                                    </ul>

                                </td>
                            </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<!-- Edit Modal -->
<div class="modal fade" id="editCompanyModal<?php echo e($company->id); ?>">
    <div class="modal-dialog">
        <form method="POST" action="<?php echo e(route('admin.companies.update',$company->id)); ?>" class="modal-content">
            <?php echo csrf_field(); ?>
            <div class="modal-header">
                <h5 class="modal-title">Edit Company</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            <div class="modal-body">
                <div class="mb-3">
                    <label>Name</label>
                    <input name="name" class="form-control"
                        value="<?php echo e($company->name ?? old('name')); ?>" required>
                </div>

                <div class="mb-3">
                    <label>Email</label>
                    <input name="email" type="email" class="form-control"
                        value="<?php echo e($company->email ?? old('email')); ?>" required>
                </div>

                <div class="mb-3">
                    <label>Phone</label>
                    <input name="phone" class="form-control"
                        value="<?php echo e($company->phone ?? old('phone')); ?>">
                </div>

                <div class="mb-3">
                    <label>Address</label>
                    <textarea name="address" class="form-control"><?php echo e($company->address ?? old('address')); ?></textarea>
                </div>

                <div class="mb-3">
                    <label>Status</label>
                    <select name="status" class="form-control" required>
                        <option value="active" <?php echo e((isset($company) && $company->status=='active')?'selected':''); ?>>Active</option>
                        <option value="suspended" <?php echo e((isset($company) && $company->status=='suspended')?'selected':''); ?>>Suspended</option>
                        <option value="inactive" <?php echo e((isset($company) && $company->status=='inactive')?'selected':''); ?>>Inactive</option>
                    </select>
                </div>

            </div>

            <div class="modal-footer">
                <button class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button class="btn btn-success">Save Changes</button>
            </div>
        </form>
    </div>
</div>

<!-- Delete Modal -->
<div class="modal fade" id="deleteCompanyModal<?php echo e($company->id); ?>">
    <div class="modal-dialog">
        <form method="POST" action="<?php echo e(route('admin.companies.destroy',$company->id)); ?>" class="modal-content">
            <?php echo csrf_field(); ?>
            <div class="modal-header">
                <h5 class="modal-title text-danger">Confirm Delete</h5>
            </div>

            <div class="modal-body">
                Are you sure you want to delete <b><?php echo e($company->name); ?></b>?
            </div>

            <div class="modal-footer">
                <button class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button class="btn btn-danger">Delete</button>
            </div>
        </form>
    </div>
</div>
<!-- Payroll Settings Modal -->
<div class="modal fade" id="payrollSettingsModal<?php echo e($company->id); ?>" tabindex="-1">
    <div class="modal-dialog">
        <form class="modal-content"
            method="POST"
            <?php if($company->payrollSettings): ?>
            action="<?php echo e(route('admin.payroll.settings.update', $company->payrollSettings->id)); ?>"
            <?php else: ?>
            action="<?php echo e(route('admin.payroll.settings.store')); ?>"
            <?php endif; ?>>

            <?php echo csrf_field(); ?>
            <?php if($company->payrollSettings): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>

            <input type="hidden" name="company_id" value="<?php echo e($company->id); ?>">

            <div class="modal-header">
                <h5>Payroll Settings — <?php echo e($company->name); ?></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            <div class="modal-body">

                <div class="mb-3">
                    <label>Salary Type</label>
                    <select name="salary_type" class="form-select">
                        <option value="fixed" <?php echo e(optional($company->payrollSettings)->salary_type=='fixed'?'selected':''); ?>>Fixed</option>
                        <option value="per_trip" <?php echo e(optional($company->payrollSettings)->salary_type=='per_trip'?'selected':''); ?>>Per Trip</option>
                    </select>
                </div>

                <div class="mb-3">
                    <label>Base Salary</label>
                    <input type="number" step="0.01" name="base_salary" class="form-control"
                        value="<?php echo e(optional($company->payrollSettings)->base_salary); ?>">
                </div>

                <div class="mb-3">
                    <label>Trip Rate</label>
                    <input type="number" step="0.01" name="trip_rate" class="form-control"
                        value="<?php echo e(optional($company->payrollSettings)->trip_rate); ?>">
                </div>

                <div class="mb-3">
                    <label>Tax Rate (%)</label>
                    <input type="number" step="0.01" name="tax_rate" class="form-control"
                        value="<?php echo e(optional($company->payrollSettings)->tax_rate); ?>">
                </div>

                <div class="mb-3">
                    <label>RSSB Rate (%)</label>
                    <input type="number" step="0.01" name="rssb_rate" class="form-control"
                        value="<?php echo e(optional($company->payrollSettings)->rssb_rate); ?>">
                </div>

            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button class="btn btn-success">Save Settings</button>
            </div>

        </form>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<!-- Create Modal -->
<div class="modal fade" id="createCompanyModal">
    <div class="modal-dialog">
        <form method="POST" action="<?php echo e(route('admin.companies.store')); ?>" class="modal-content">
            <?php echo csrf_field(); ?>
            <div class="modal-header">
                <h5 class="modal-title">Create Company</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            <div class="modal-body">
                <div class="mb-3">
                    <label>Name</label>
                    <input name="name" class="form-control"required>
                </div>

                <div class="mb-3">
                    <label>Email</label>
                    <input name="email" type="email" class="form-control"required>
                </div>

                <div class="mb-3">
                    <label>Phone</label>
                    <input name="phone" class="form-control">
                </div>

                <div class="mb-3">
                    <label>Address</label>
                    <textarea name="address" class="form-control"></textarea>
                </div>

                <div class="mb-3">
                    <label>Status</label>
                    <select name="status" class="form-control" required>
                        <option value="active" >Active</option>
                        <option value="suspended" >Suspended</option>
                        <option value="inactive" >Inactive</option>
                    </select>
                </div>

            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Create</button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\atpr rwanda\driver-cards-system\resources\views/admin/companies/index.blade.php ENDPATH**/ ?>