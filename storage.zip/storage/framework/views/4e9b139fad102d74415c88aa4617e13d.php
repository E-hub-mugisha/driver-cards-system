
<?php $__env->startSection('title','Driver Behavior Reports'); ?>
<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    <div class="nk-content-inner">
        <div class="nk-content-body">
            <div class="card p-4">
                <h5 class="mb-3">Company: <?php echo e($company->name ?? 'N/A'); ?></h5>

                <table class="datatable-init nowrap nk-tb-list nk-tb-ulist">
                    <thead>
                        <tr class="nk-tb-item nk-tb-head">
                            <th class="nk-tb-col">#</th>
                            <th class="nk-tb-col">Driver</th>
                            <th class="nk-tb-col">Behaviors Reported</th>
                            <th class="nk-tb-col">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $drivers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $driver): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="nk-tb-item">
                            <td class="nk-tb-col"><?php echo e($index + 1); ?></td>
                            <td class="nk-tb-col"><?php echo e($driver->names); ?></td>
                            <td class="nk-tb-col"><span class="badge bg-danger">Reported <?php echo e($driver->behaviors_count); ?></span></td>
                            <td class="nk-tb-col">
                                <?php if($driver->behaviors_count > 0): ?>
                                <a href="<?php echo e(route('company.driver.behaviors', $driver->id)); ?>" class="btn btn-sm btn-info">
                                    View Details
                                </a>
                                <?php else: ?>
                                <span class="text-muted">No Records</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="4" class="text-center">No drivers found.</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\atpr rwanda\driver-cards-system\resources\views/company/behaviors/drivers.blade.php ENDPATH**/ ?>