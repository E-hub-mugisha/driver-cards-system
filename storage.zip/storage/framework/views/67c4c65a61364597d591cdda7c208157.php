<div class="nk-header nk-header-fixed is-light">
  <div class="container-fluid">
    <div class="nk-header-wrap">
      <div class="nk-menu-trigger d-xl-none ms-n1"><a href="#"
          class="nk-nav-toggle nk-quick-nav-icon" data-target="sidebarMenu"><em
            class="icon ni ni-menu"></em></a></div>
      <div class="nk-header-brand d-xl-none"><a href="#" class="logo-link"><img
            class="logo-light logo-img" src="<?php echo e(asset('assets/images/atpr_logo.png')); ?>"
            srcset="<?php echo e(asset('assets/images/atpr_logo.png')); ?>" alt="logo"><img class="logo-dark logo-img"
            src="<?php echo e(asset('assets/images/atpr_logo.png')); ?>" srcset="<?php echo e(asset('assets/images/atpr_logo.png')); ?>"
            alt="logo-dark"></a></div>
      <div class="nk-header-news d-none d-xl-block">
        <div class="nk-news-list"><a class="nk-news-item" href="#">
            <div class="nk-news-icon"><em class="icon ni ni-card-view"></em></div>
            <div class="nk-news-text">
              <p><span> <?php echo e(config('app.name')); ?></span></p><em class="icon ni ni-external"></em>
            </div>
          </a></div>
      </div>
      <div class="nk-header-tools">
        <ul class="nk-quick-nav">
          <li class="dropdown user-dropdown"><a href="#" class="dropdown-toggle"
              data-bs-toggle="dropdown">
              <div class="user-toggle">
                <div class="user-avatar sm"><em class="icon ni ni-user-alt"></em></div>
                <div class="user-info d-none d-md-block">
                  <div class="user-status"><?php echo e(Auth::user()->type); ?></div>
                  <div class="user-name dropdown-indicator"><?php echo e(Auth::user()->name); ?></div>
                </div>
              </div>
            </a>
            <div class="dropdown-menu dropdown-menu-md dropdown-menu-end dropdown-menu-s1">
              <div class="dropdown-inner user-card-wrap bg-lighter d-none d-md-block">
                <div class="user-card">
                  <div class="user-avatar"><span>AB</span></div>
                  <div class="user-info">
                    <span class="lead-text">
                      <?php echo e(Auth::user()->name); ?>

                    </span>
                    <span class="sub-text"><?php echo e(Auth::user()->email); ?></span>
                  </div>
                </div>
              </div>
              <div class="dropdown-inner">
                <ul class="link-list">
                  <li><a href="#"><em
                        class="icon ni ni-user-alt"></em><span>View
                        Profile</span></a></li>
                  <li><a href="#"><em
                        class="icon ni ni-setting-alt"></em><span>Account
                        Setting</span></a></li>
                </ul>
              </div>
              <div class="dropdown-inner">
                <ul class="link-list">
                  <li>
                    <a href="#" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                      <em class="icon ni ni-signout"></em>
                      <span>Sign out</span>
                    </a>
                  </li>
                  <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                    <?php echo csrf_field(); ?>
                  </form>
                </ul>
              </div>
            </div>
          </li>
         
        </ul>
      </div>
    </div>
  </div>
</div><?php /**PATH D:\atpr rwanda\driver-cards-system\resources\views/layouts/header.blade.php ENDPATH**/ ?>