
<?php $__env->startSection('title', 'Drivers with behavior'); ?>
<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    <div class="nk-content-inner">
        <div class="nk-content-body">
            <div class="nk-block-head nk-block-head-sm">
                <div class="nk-block-between">
                    <div class="nk-block-head-content">
                        <h3 class="nk-block-title page-title">Drivers with behavior:
                            <span class="badge bg-primary"><?php echo e($behavior->name); ?></span>
                        </h3>
                    </div>
                    <div class="nk-block-head-content">
                        <div class="toggle-wrap nk-block-tools-toggle">
                            <a href="<?php echo e(route('admin.behaviors.index')); ?>" class="btn btn-secondary rounded-5">
                                <em class="icon ni ni-arrow-left"></em> Back to Behaviors
                            </a>
                        </div>
                    </div>
                </div>

                <div class="nk-block nk-block-lg p-4 bg-white rounded-5 mt-5">
                    <div class="nk-block-head">
                        <div class="nk-block-head-content">
                            <div class="nk-block-des">
                                <h5>Total Drivers: <?php echo e($drivers->total()); ?></h5>
                                <table class="datatable-init nowrap nk-tb-list nk-tb-ulist">
                                    <thead>
                                        <tr class="nk-tb-item nk-tb-head">
                                            <th class="nk-tb-col">#</th>
                                            <th class="nk-tb-col">Driver</th>
                                            <th class="nk-tb-col">License</th>
                                            <th class="nk-tb-col">Company</th>
                                            <th class="nk-tb-col">Reported On</th>
                                            <th class="nk-tb-col">Severity</th>
                                            <th class="nk-tb-col">Score</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__empty_1 = true; $__currentLoopData = $drivers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr class="nk-tb-item">
                                            <td class="nk-tb-col"><?php echo e($loop->iteration); ?></td>
                                            <td class="nk-tb-col"><?php echo e($row->driver->names); ?></td>
                                            <td class="nk-tb-col"><?php echo e($row->driver->driver_license); ?></td>
                                            <td class="nk-tb-col"><?php echo e($row->driver->company->name); ?></td>
                                            <td class="nk-tb-col"><?php echo e($row->created_at?->format('d M Y')); ?></td>
                                            <td class="nk-tb-col">
                                                <span class="<?php if($row->severity === 'low'): ?> text-info <?php elseif($row->severity === 'medium'): ?> text-warning                        <?php else: ?> text-danger <?php endif; ?>">
                                                    <em class="icon ni ni-alert"></em> <?php echo e(ucfirst($row->severity)); ?>

                                                </span>
                                            </td>
                                            <td class="nk-tb-col"><?php echo e($row->score); ?></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr class="nk-tb-item">
                                            <td colspan="5" class="text-center text-muted">
                                                No drivers found for this behavior
                                            </td>
                                        </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\atpr rwanda\driver-cards-system\resources\views/admin/behaviors/drivers.blade.php ENDPATH**/ ?>