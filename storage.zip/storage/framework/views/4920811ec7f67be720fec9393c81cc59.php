<?php $__env->startSection('title', 'Driver Behaviors'); ?>
<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    <div class="nk-content-inner">
        <div class="nk-content-body">
            <div class="nk-block-head nk-block-head-sm">
                <div class="nk-block-between">
                    <div class="nk-block-head-content">
                        <h3 class="nk-block-title page-title">Driver Behaviors</h3>
                    </div>
                    <div class="nk-block-head-content">
                        <div class="toggle-wrap nk-block-tools-toggle"><a href="#"
                                class="btn btn-icon btn-trigger toggle-expand me-n1"
                                data-target="pageMenu"><em class="icon ni ni-more-v"></em></a>
                            <div class="toggle-expand-content" data-content="pageMenu">
                                <ul class="nk-block-tools g-3">
                                    <li class="nk-block-tools-opt">
                                        <a href="#"
                                            data-bs-toggle="modal"
                                            data-bs-target="#addBehaviorModal"
                                            class="btn btn-icon btn-primary d-md-none">
                                            <em class="icon ni ni-plus"></em>
                                        </a>

                                        <a href="#"
                                            data-bs-toggle="modal"
                                            data-bs-target="#addBehaviorModal"
                                            class="btn btn-primary d-none d-md-inline-flex">
                                            <em class="icon ni ni-plus"></em>
                                            <span>Add Behavior</span>
                                        </a>

                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <strong>Something went wrong!</strong>
                    <ul class="mb-0 mt-2">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <?php endif; ?>
                <div class="nk-block nk-block-lg">
                    <div class="nk-block-head">
                        <div class="nk-block-head-content">
                            <div class="nk-block-des">
                                <p>Lists of behavior that are involved in drivers</p>
                            </div>
                        </div>
                    </div>
                    <div class="card rounded-5 shadow-sm">
                        <div class="card-body">

                            <div class="row">

                                <!-- LEFT: CATEGORY MENU -->
                                <div class="col-md-3">
                                    <ul class="nav link-list-menu round-5 shadow-sm" role="tablist">
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="p-4">
                                            <span class="badge bg-secondary">
                                                <?php echo e($category->behaviorTypes->count()); ?>

                                            </span>
                                            <a class="nav-link <?php echo e($index==0?'active':''); ?>"
                                                data-bs-toggle="tab"
                                                href="#tabItem-<?php echo e($category->id); ?>">

                                                <?php echo e($category->name); ?>


                                            </a>

                                        </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>

                                <!-- RIGHT: CONTENT -->
                                <div class="col-md-9">
                                    <div class="tab-content">

                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="tab-pane fade <?php echo e($index==0?'show active':''); ?>"
                                            id="tabItem-<?php echo e($category->id); ?>">

                                            <!-- SEARCH -->
                                            <div class="mb-2">
                                                <input type="text"
                                                    class="form-control form-control-sm"
                                                    placeholder="Search behavior..."
                                                    onkeyup="
                                        let rows=document.querySelectorAll('#table-<?php echo e($category->id); ?> tbody tr');
                                        rows.forEach(r=>r.style.display=
                                            r.innerText.toLowerCase().includes(this.value.toLowerCase())
                                            ? '' : 'none'
                                        );
                                    ">
                                            </div>

                                            <table class="datatable-init nowrap nk-tb-list nk-tb-ulist"
                                                id="table-<?php echo e($category->id); ?>">
                                                <thead>
                                                    <tr class="nk-tb-item nk-tb-head">
                                                        <th class="nk-tb-col">Name</th>
                                                        <th class="nk-tb-col">Type</th>
                                                        <th class="nk-tb-col">Severity</th>
                                                        <th class="nk-tb-col">Score</th>
                                                        <th class="nk-tb-col nk-tb-col-tools text-end"></th>
                                                    </tr>
                                                </thead>

                                                <tbody>
                                                    <?php $__empty_1 = true; $__currentLoopData = $category->behaviorTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $behavior): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                    <tr class="nk-tb-item">
                                                        <td class="nk-tb-col"><?php echo e($behavior->name); ?></td>

                                                        <td class="nk-tb-col">
                                                            <span class="badge bg-<?php echo e($behavior->category=='positive'?'success':'danger'); ?>">
                                                                <?php echo e(ucfirst($behavior->category)); ?>

                                                            </span>
                                                        </td>

                                                        <td class="nk-tb-col">
                                                            <span class="badge
                                                <?php if($behavior->severity=='low'): ?> bg-info
                                                <?php elseif($behavior->severity=='medium'): ?> bg-warning
                                                <?php else: ?> bg-danger <?php endif; ?>">
                                                                <?php echo e(ucfirst($behavior->severity)); ?>

                                                            </span>
                                                        </td>

                                                        <td class="nk-tb-col"><?php echo e($behavior->default_score); ?></td>

                                                        <td class="nk-tb-col nk-tb-col-tools">
                                                            <ul class="nk-tb-actions gx-1">
                                                                <li>
                                                                    <div class="drodown"><a href="#"
                                                                            class="dropdown-toggle btn btn-icon btn-trigger"
                                                                            data-bs-toggle="dropdown"><em
                                                                                class="icon ni ni-more-h"></em></a>
                                                                        <div class="dropdown-menu dropdown-menu-end">
                                                                            <ul class="link-list-opt no-bdr">
                                                                                <li>
                                                                                    <a href="<?php echo e(route('admin.behaviors.drivers',$behavior)); ?>"
                                                                                        class="text-success">
                                                                                        Drivers (<?php echo e($behavior->driverBehaviors->count()); ?>)
                                                                                    </a>
                                                                                </li>
                                                                                <li>
                                                                                    <a href="#" class="text-primary" data-bs-toggle="modal" data-bs-target="#editBehaviorModal-<?php echo e($behavior->id); ?>">
                                                                                        Edit
                                                                                    </a>
                                                                                </li>
                                                                                <li>
                                                                                    <?php if($behavior->driverBehaviors->count() > 0): ?>
                                                                                    <a href="#" class="text-info" disabled>
                                                                                        In Use
                                                                                    </a>
                                                                                    <?php else: ?>
                                                                                    <form method="POST"
                                                                                        action="<?php echo e(route('admin.behaviors.destroy',$behavior)); ?>"
                                                                                        class="d-inline">
                                                                                        <?php echo csrf_field(); ?>
                                                                                        <?php echo method_field('DELETE'); ?>
                                                                                        <button class="text-danger btn">
                                                                                            Delete
                                                                                        </button>
                                                                                    </form>
                                                                                    <?php endif; ?>
                                                                                </li>
                                                                            </ul>
                                                                        </div>
                                                                    </div>
                                                                </li>
                                                            </ul>
                                                        </td>
                                                    </tr>

                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                    <tr>
                                                        <td colspan="5" class="text-center text-muted">
                                                            No behaviors found
                                                        </td>
                                                    </tr>
                                                    <?php endif; ?>
                                                </tbody>
                                            </table>

                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </div>
                                </div>

                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php $__empty_1 = true; $__currentLoopData = $category->behaviorTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $behavior): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

<!-- EDIT MODAL -->
<div class="modal fade"
    id="editBehaviorModal-<?php echo e($behavior->id); ?>">
    <div class="modal-dialog">
        <form method="POST"
            action="<?php echo e(route('admin.behaviors.update',$behavior)); ?>"
            class="modal-content">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="modal-header">
                <h5>Edit Behavior</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            <div class="modal-body">

                <input name="name"
                    value="<?php echo e($behavior->name); ?>"
                    class="form-control mb-2"
                    required>

                <select name="category" class="form-control mb-2">
                    <option value="negative" <?php if($behavior->category=='negative'): echo 'selected'; endif; ?>>
                        Negative
                    </option>
                    <option value="positive" <?php if($behavior->category=='positive'): echo 'selected'; endif; ?>>
                        Positive
                    </option>
                </select>

                <select name="severity" class="form-control mb-2">
                    <option value="low" <?php if($behavior->severity=='low'): echo 'selected'; endif; ?>>Low</option>
                    <option value="medium" <?php if($behavior->severity=='medium'): echo 'selected'; endif; ?>>Medium</option>
                    <option value="high" <?php if($behavior->severity=='high'): echo 'selected'; endif; ?>>High</option>
                </select>

                <input type="number"
                    name="default_score"
                    value="<?php echo e($behavior->default_score); ?>"
                    class="form-control">
            </div>

            <div class="modal-footer">
                <button class="btn btn-primary">Update</button>
            </div>
        </form>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<!-- ADD MODAL -->
<div class="modal fade" id="addBehaviorModal">
    <div class="modal-dialog">
        <form method="POST"
            action="<?php echo e(route('admin.behaviors.store')); ?>"
            class="modal-content">
            <?php echo csrf_field(); ?>

            <div class="modal-header">
                <h5>Add Behavior</h5>
                <button class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            <div class="modal-body">

                <select name="behavior_category_id"
                    class="form-control mb-2" required>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($category->id); ?>">
                        <?php echo e($category->name); ?>

                    </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

                <input name="name" class="form-control mb-2" required>

                <select name="category" class="form-control mb-2">
                    <option value="negative">Negative</option>
                    <option value="positive">Positive</option>
                </select>

                <select name="severity" class="form-control mb-2">
                    <option value="low">Low</option>
                    <option value="medium">Medium</option>
                    <option value="high">High</option>
                </select>

                <input type="number"
                    name="default_score"
                    class="form-control">
            </div>

            <div class="modal-footer">
                <button class="btn btn-primary">Save</button>
            </div>

        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\atpr rwanda\driver-cards-system\resources\views/admin/behaviors/index.blade.php ENDPATH**/ ?>