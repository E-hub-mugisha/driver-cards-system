<?php $__env->startSection('title', $company->name . " — Drivers"); ?>
<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    <div class="nk-content-inner">
        <div class="nk-content-body">
            <div class="nk-block-head nk-block-head-sm">
                <div class="nk-block-between">
                    <div class="nk-block-head-content">
                        <h3 class="nk-block-title page-title"><?php echo e($company->name); ?> — Drivers Management</h3>
                    </div>
                    <div class="nk-block-head-content">
                        <button class="btn btn-primary mb-3" data-bs-toggle="modal" data-bs-target="#addDriverModal">
                            Add Driver
                        </button>
                    </div>
                </div>

                <?php if(session('success')): ?>
                <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                <?php endif; ?>

                <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <strong>Whoops!</strong> Please fix the following issues:
                    <ul class="mt-2 mb-0">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <?php endif; ?>
                <div class="nk-block nk-block-lg p-4 bg-white rounded-5">
                    <div class="nk-block-head">
                        <div class="nk-block-head-content">
                            <div class="nk-block-des">
                                <h5>Active & Inactive Drivers</h5>
                                <table class="datatable-init nowrap nk-tb-list nk-tb-ulist">
                                    <thead>
                                        <tr class="nk-tb-item nk-tb-head">
                                            <th class="nk-tb-col">#</th>
                                            <th class="nk-tb-col">Photo</th>
                                            <th class="nk-tb-col">Name</th>
                                            <th class="nk-tb-col">ID</th>
                                            <th class="nk-tb-col">License</th>
                                            <th class="nk-tb-col">Phone</th>
                                            <th class="nk-tb-col">Company</th>
                                            <th class="nk-tb-col">Status</th>
                                            <th class="nk-tb-col nk-tb-col-tools text-end"></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $drivers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $driver): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(!$driver->trashed()): ?>
                                        <tr class="nk-tb-item">
                                            <td class="nk-tb-col"><?php echo e($loop->iteration); ?></td>
                                            <td class="nk-tb-col">
                                                <?php if($driver->photo): ?>
                                                <img src="<?php echo e(asset('storage/'.$driver->photo)); ?>" width="50">
                                                <?php endif; ?>
                                            </td>
                                            <td class="nk-tb-col"><?php echo e($driver->names); ?></td>
                                            <td class="nk-tb-col"><?php echo e($driver->ID_number); ?></td>
                                            <td class="nk-tb-col"><?php echo e($driver->driver_license); ?></td>
                                            <td class="nk-tb-col"><?php echo e($driver->phone); ?></td>
                                            <td class="nk-tb-col"><?php echo e($driver->company?->name ?? '-'); ?></td>
                                            <td class="nk-tb-col"><?php echo e(ucfirst($driver->status)); ?></td>
                                            <td class="nk-tb-col nk-tb-col-tools">
                                                <ul class="nk-tb-actions gx-1">
                                                    <li>
                                                        <div class="drodown"><a href="#"
                                                                class="dropdown-toggle btn btn-icon btn-trigger"
                                                                data-bs-toggle="dropdown"><em
                                                                    class="icon ni ni-more-h"></em></a>
                                                            <div
                                                                class="dropdown-menu dropdown-menu-end">
                                                                <ul class="link-list-opt no-bdr">
                                                                    <li>
                                                                        <a href="<?php echo e(route('admin.drivers.show', $driver->id )); ?>" class="text-info">View Details</a>
                                                                    </li>
                                                                    <li>
                                                                        <a role="button" class="text-warning" data-bs-toggle="modal" data-bs-target="#editDriverModal<?php echo e($driver->id); ?>">Edit</a>
                                                                    </li>
                                                                    <li>
                                                                        <a role="button" class="text-danger" data-bs-toggle="modal" data-bs-target="#deleteDriverModal<?php echo e($driver->id); ?>">Remove</a>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="nk-block nk-block-lg p-4 bg-white rounded-5 mt-5">
                    <div class="nk-block-head">
                        <div class="nk-block-head-content">
                            <div class="nk-block-des">
                                <h5>Deleted Drivers</h5>
                                <table class="datatable-init nowrap nk-tb-list nk-tb-ulist">
                                    <thead>
                                        <tr class="nk-tb-item nk-tb-head">
                                            <th class="nk-tb-col">#</th>
                                            <th class="nk-tb-col">Photo</th>
                                            <th class="nk-tb-col">Name</th>
                                            <th class="nk-tb-col">ID</th>
                                            <th class="nk-tb-col">License</th>
                                            <th class="nk-tb-col">Phone</th>
                                            <th class="nk-tb-col">Company</th>
                                            <th class="nk-tb-col">Status</th>
                                            <th class="nk-tb-col nk-tb-col-tools text-end"></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $drivers->whereNotNull('deleted_at'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $driver): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="nk-tb-item">
                                            <td class="nk-tb-col"><?php echo e($loop->iteration); ?></td>
                                            <td class="nk-tb-col">
                                                <?php if($driver->photo): ?>
                                                <img src="<?php echo e(asset('storage/'.$driver->photo)); ?>" width="50">
                                                <?php endif; ?>
                                            </td>
                                            <td class="nk-tb-col"><?php echo e($driver->names); ?></td>
                                            <td class="nk-tb-col"><?php echo e($driver->ID_number); ?></td>
                                            <td class="nk-tb-col"><?php echo e($driver->driver_license); ?></td>
                                            <td class="nk-tb-col"><?php echo e($driver->phone); ?></td>
                                            <td class="nk-tb-col"><?php echo e($driver->company?->name ?? '-'); ?></td>
                                            <td class="nk-tb-col"><?php echo e(ucfirst($driver->status)); ?></td>
                                            <td class="nk-tb-col nk-tb-col-tools">
                                                <ul class="nk-tb-actions gx-1">
                                                    <li>
                                                        <div class="drodown"><a href="#"
                                                                class="dropdown-toggle btn btn-icon btn-trigger"
                                                                data-bs-toggle="dropdown"><em
                                                                    class="icon ni ni-more-h"></em></a>
                                                            <div
                                                                class="dropdown-menu dropdown-menu-end">
                                                                <ul class="link-list-opt no-bdr">
                                                                    <li>
                                                                        <a href="<?php echo e(route('admin.drivers.show', $driver->id )); ?>" class="text-info">View Details</a>
                                                                    </li>
                                                                    <li>
                                                                        <form action="<?php echo e(route('admin.drivers.restore',$driver->id)); ?>" method="POST" class="d-inline">
                                                                            <?php echo csrf_field(); ?>
                                                                            <button class="btn btn-success btn-sm">Restore</button>
                                                                        </form>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="addDriverModal">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form method="POST" action="<?php echo e(route('admin.company.drivers.store',$company->id)); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="modal-header">
                    <h5 class="modal-title">Add Driver</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label>Name</label>
                            <input type="text" name="names" class="form-control" required>
                        </div>
                        <div class="col-md-6">
                            <label>ID Number</label>
                            <input type="text" name="ID_number" class="form-control" required>
                        </div>
                        <div class="col-md-6">
                            <label>Driver License</label>
                            <input type="text" name="driver_license" class="form-control" required>
                        </div>
                        <div class="col-md-6">
                            <label>Phone</label>
                            <input type="text" name="phone" class="form-control" required>
                        </div>
                        <div class="col-md-6">
                            <label>RSSB Number</label>
                            <input type="text" name="rssb" class="form-control">
                        </div>
                        <div class="col-md-6">
                            <label>Insurance</label>
                            <select name="insurance" class="form-select">
                                <option selected disabled>-- select insurance --</option>
                                <option>YES</option>
                                <option>NO</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label>Contract Type</label>
                            <select name="contract_type" class="form-select">
                                <option selected disabled>-- select contract type --</option>
                                <option value="3 month">3 Month</option>
                                <option value="6 month">6 Month</option>
                                <option value="12 month">12 Month</option>
                                <option value="open ended">Open Ended</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label>Status</label>
                            <select name="status" class="form-control">
                                <option value="active">Active</option>
                                <option value="inactive">Inactive</option>
                                <option value="suspended">Suspended</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label>Photo</label>
                            <input type="file" name="photo" class="form-control">
                        </div>
                        <div class="col-md-6">
                            <label>Contract</label>
                            <input type="file" name="contract" class="form-control">
                        </div>
                    </div> bg-white rounded-5
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Add Driver</button>
                </div>
            </form>
        </div>
    </div>
</div>


<?php $__currentLoopData = $drivers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $driver): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if(!$driver->trashed()): ?>
<!-- Edit Driver Modal -->
<div class="modal fade" id="editDriverModal<?php echo e($driver->id); ?>">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form method="POST" action="<?php echo e(route('admin.company.drivers.update', [$company->id,$driver->id])); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="modal-header">
                    <h5 class="modal-title">Edit Driver</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label>Name</label>
                            <input type="text" name="names" class="form-control" value="<?php echo e($driver->names); ?>" required>
                        </div>
                        <div class="col-md-6">
                            <label>ID Number</label>
                            <input type="text" name="ID_number" class="form-control" value="<?php echo e($driver->ID_number); ?>" required>
                        </div>
                        <div class="col-md-6">
                            <label>Driver License</label>
                            <input type="text" name="driver_license" class="form-control" value="<?php echo e($driver->driver_license); ?>" required>
                        </div>
                        <div class="col-md-6">
                            <label>Phone</label>
                            <input type="text" name="phone" class="form-control" value="<?php echo e($driver->phone); ?>" required>
                        </div>
                        <div class="col-md-6">
                            <label>RSSB Number</label>
                            <input type="text" name="rssb" class="form-control" value="<?php echo e($driver->rssb); ?>">
                        </div>
                        <div class="col-md-6">
                            <label>Insurance</label>
                            <select name="insurance" class="form-select">
                                <option>YES</option>
                                <option>NO</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label>Contract Type</label>
                            <select name="contract_type" class="form-select">
                                <option value="3 month" <?php echo e($driver->contract_type=='3 month'?'selected':''); ?>>3 Month</option>
                                <option value="6 month" <?php echo e($driver->contract_type=='6 month'?'selected':''); ?>>6 Month</option>
                                <option value="12 month" <?php echo e($driver->contract_type=='12 month'?'selected':''); ?>>12 Month</option>
                                <option value="open ended" <?php echo e($driver->contract_type=='open ended'?'selected':''); ?>>Open Ended</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label>Status</label>
                            <select name="status" class="form-control">
                                <option value="active" <?php echo e($driver->status=='active'?'selected':''); ?>>Active</option>
                                <option value="inactive" <?php echo e($driver->status=='inactive'?'selected':''); ?>>Inactive</option>
                                <option value="suspended" <?php echo e($driver->status=='suspended'?'selected':''); ?>>Suspended</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label>Photo</label>
                            <input type="file" name="photo" class="form-control">
                            <?php if($driver->photo): ?>
                            <small>Current: <a href="<?php echo e(asset('storage/'.$driver->photo)); ?>" target="_blank">View</a></small>
                            <?php endif; ?>
                        </div>
                        <div class="col-md-6">
                            <label>Contract</label>
                            <input type="file" name="contract" class="form-control">
                            <?php if($driver->contract): ?>
                            <small>Current: <a href="<?php echo e(asset('storage/'.$driver->contract)); ?>" target="_blank">View</a></small>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button class="btn btn-success">Update</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Delete Driver Modal -->
<div class="modal fade" id="deleteDriverModal<?php echo e($driver->id); ?>">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST" action="<?php echo e(route('admin.company.drivers.delete', [$company->id,$driver->id])); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <div class="modal-header">
                    <h5 class="modal-title text-danger">Confirm Remove</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    Are you sure you want to remove <b><?php echo e($driver->names); ?></b>?
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-danger">Remove</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\atpr rwanda\driver-cards-system\resources\views/admin/companies/drivers/index.blade.php ENDPATH**/ ?>