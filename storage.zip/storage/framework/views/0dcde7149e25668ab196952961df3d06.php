
<?php $__env->startSection('title', 'Driver Behaviors'); ?>
<?php $__env->startSection('content'); ?>
<div class="container mt-4">

    <h4>Select Company to View Driver Behaviors</h4>

    <div class="card mt-3">
        <div class="card-body">

            <form method="GET" action="<?php echo e(route('admin.company.behavior.page')); ?>">
                <div class="row align-items-end">

                    <div class="col-md-6">
                        <label class="form-label">Company</label>
                        <select name="company_id" class="form-control" required>
                            <option value="">-- Select Company --</option>

                            <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($company->id); ?>"
                                    <?php echo e(request('company_id') == $company->id ? 'selected' : ''); ?>>
                                    <?php echo e($company->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="col-md-3">
                        <button class="btn btn-primary w-100">View Drivers</button>
                    </div>

                </div>
            </form>

            <hr>

            <?php if($selectedCompany): ?>

                <h5 class="mb-3">Company: <?php echo e($selectedCompany->name); ?></h5>

                <table class="datatable-init nowrap nk-tb-list nk-tb-ulist">
                    <thead>
                        <tr class="nk-tb-item nk-tb-head">
                            <th class="nk-tb-col">#</th>
                            <th class="nk-tb-col">Driver</th>
                            <th class="nk-tb-col">Behaviors Reported</th>
                            <th class="nk-tb-col">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $drivers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $driver): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="nk-tb-item">
                            <td class="nk-tb-col"><?php echo e($index + 1); ?></td>
                            <td class="nk-tb-col"><?php echo e($driver->names); ?></td>
                            <td class="nk-tb-col"><span class="badge bg-danger">Reported <?php echo e($driver->behaviors_count); ?></span></td>
                            <td class="nk-tb-col">
                                <?php if($driver->behaviors_count > 0): ?>
                                <a href="<?php echo e(route('admin.driver.behaviors', $driver->id)); ?>" class="btn btn-sm btn-info">
                                    View Details
                                </a>
                                <?php else: ?>
                                <span class="text-muted">No Records</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="4" class="text-center">No drivers found.</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>

            <?php else: ?>
                <div class="text-muted">
                    Select a company to view drivers.
                </div>
            <?php endif; ?>

        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\atpr rwanda\driver-cards-system\resources\views/admin/behaviors/company-drivers.blade.php ENDPATH**/ ?>