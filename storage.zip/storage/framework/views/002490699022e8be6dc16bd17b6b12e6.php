<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH D:\atpr rwanda\driver-cards-system\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/header.blade.php ENDPATH**/ ?>